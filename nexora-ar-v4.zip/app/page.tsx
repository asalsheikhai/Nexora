import { Camera, Sparkles } from "lucide-react";
import WhatsAppCTA from "@/components/WhatsAppCTA";
import ARButton from "@/components/ARButton";
import LeadForm from "@/components/LeadForm";
import Section from "@/components/Section";
import { Button } from "@/components/ui/button";
function Badge({ children }: { children: React.ReactNode }) { return <span className="badge">{children}</span>; }
export default function Page() {
  return (<main className="text-white">
    <header className="container py-6 flex items-center justify-between">
      <div className="flex items-center gap-3"><img src="/logo.svg" alt="NexoraLuxe" className="h-8 w-8" /><span className="uppercase tracking-widest text-sm text-neutral-300">NEXORA<span className="text-luxe-brass">LUXE</span></span></div>
      <div className="hidden md:flex items-center gap-3"><ARButton /><WhatsAppCTA /></div>
    </header>
    <section className="container">
      <div className="card p-6 md:p-10 flex flex-col md:flex-row items-center gap-8">
        <div className="flex-1 space-y-4">
          <Badge>Control the Light</Badge>
          <h1 className="text-3xl md:text-5xl font-semibold leading-tight">AR Showroom — Graphite Micro-Cement + Brass Wash</h1>
          <p className="text-neutral-400">Touch the fabric, feel the silence. Zebra / Dual-mechanism / Motorized. Designed for architects and obsessive people.</p>
          <div className="flex flex-wrap gap-3"><Button>Launch AR</Button><Button variant="brass">WhatsApp</Button></div>
          <p className="text-xs text-neutral-500">Made in Iran • Lifetime service • 48h install (Tehran)</p>
        </div>
        <div className="flex-1"><img src="/hero.jpg" alt="AR Hero" className="rounded-2xl border border-neutral-800" /></div>
      </div>
    </section>
    <Section title="Signature Pieces" subtitle="9:16 ready for Instagram — realtime materials & lighting.">
      <div className="grid md:grid-cols-3 gap-6">
        {["Gold Moon","Nexora Gold","Pink Leopard Accent"].map((name,i)=>(
          <div key={i} className="card p-4">
            <img src={`/gallery/${i+1}.jpg`} alt={name} className="rounded-xl mb-3 border border-neutral-800" />
            <div className="flex items-center justify-between">
              <div><h3 className="font-medium">{name}</h3><p className="text-xs text-neutral-400">50mm f/2.8 • Portra400 grain</p></div>
              <Button size="sm">View</Button>
            </div>
          </div>
        ))}
      </div>
    </Section>
    <Section title="Specs" subtitle="Engineered for silence, precision, and visual calm.">
      <div className="grid md:grid-cols-3 gap-6">
        <div className="card p-5"><h4 className="font-medium mb-2">Mechanism</h4><ul className="text-sm text-neutral-400 space-y-1"><li>Dual / Motorized (Somfy-compatible)</li><li>Precision aluminum rails — Nero Ingo finish</li><li>Silent dampers — 28dB</li></ul></div>
        <div className="card p-5"><h4 className="font-medium mb-2">Fabric</h4><ul className="text-sm text-neutral-400 space-y-1"><li>Zebra weave — Italian dye</li><li>UV block 98% — thermal control</li><li>Custom Art Shade prints — 1/1 to 3/3</li></ul></div>
        <div className="card p-5"><h4 className="font-medium mb-2">Install</h4><ul className="text-sm text-neutral-400 space-y-1"><li>Wall-wash brass lighting</li><li>48h install (Tehran) • COA included</li><li>Architect kit available</li></ul></div>
      </div>
    </Section>
    <Section title="Get a Quote" subtitle="ارسال اسم، شماره و توضیح کوتاه — در کمتر از ۱ ساعت تماس می‌گیریم.">
      <div className="grid md:grid-cols-2 gap-6">
        <div className="card p-5"><LeadForm /></div>
        <div className="card p-5 space-y-3">
          <div className="flex items-center gap-3"><span className="text-luxe-brass">📷</span><p className="text-neutral-300 text-sm">می‌تونی عکس فضای نصب رو بفرستی؛ سایز و رنگ دقیق‌تر می‌دیم.</p></div>
          <div className="flex items-center gap-3"><span className="text-luxe-brass">✨</span><p className="text-neutral-300 text-sm">Art Shade چاپ اختصاصی، با امضا و شماره سریال.</p></div>
        </div>
      </div>
    </Section>
    <footer className="container py-10 text-sm text-neutral-500 flex items-center justify-between">
      <p>© {new Date().getFullYear()} NexoraLuxe — All rights reserved.</p>
      <div className="flex gap-5"><a href="/privacy">Privacy</a><a href="/terms">Terms</a><a href="/crm">CRM</a></div>
    </footer>
  </main>);
}
