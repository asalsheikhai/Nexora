import { NextResponse } from "next/server";
export const dynamic = "force-dynamic";
export async function GET() {
  const csvUrl = process.env.SHEETS_PUBLISHED_CSV_URL;
  if (!csvUrl) return NextResponse.json([]);
  try {
    const res = await fetch(csvUrl, { next: { revalidate: 0 } });
    const text = await res.text();
    const rows = parseCSV(text);
    const [header, ...data] = rows;
    const idx: Record<string, number> = {};
    header.forEach((h: string, i: number) => idx[h.trim().toLowerCase()] = i);
    const mapped = data.map((r: string[]) => ({
      ts: r[idx['timestamp']] || r[idx['ts']] || r[0],
      name: r[idx['name']] || r[1],
      phone: r[idx['phone']] || r[2],
      note: r[idx['note']] || r[3],
      ip: r[idx['ip']] || r[4],
      ua: r[idx['ua']] || r[5],
      path: r[idx['path']] || r[6],
      utm: safeParseJSON(r[idx['utm']] || '') || r[idx['utm']] || null
    }));
    return NextResponse.json(mapped);
  } catch (e) { return NextResponse.json([]); }
}
function parseCSV(input: string): string[][] {
  const rows: string[][] = []; let row: string[] = []; let cur = ''; let inQuotes = false;
  for (let i=0; i<input.length; i++) {
    const ch = input[i];
    if (inQuotes) { if (ch === '"') { if (input[i+1] === '"') { cur += '"'; i++; } else { inQuotes = false; } } else { cur += ch; } }
    else { if (ch === '"') { inQuotes = true; } else if (ch === ',') { row.push(cur); cur = ''; } else if (ch === '\n') { row.push(cur); rows.push(row); row = []; cur=''; } else if (ch !== '\r') { cur += ch; } }
  }
  row.push(cur); rows.push(row);
  return rows.filter(r => r.length && !(r.length===1 && r[0]===''));
}
function safeParseJSON(t: string) { try { return JSON.parse(t); } catch { return null; } }
